import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Em dev, o Vite roda em localhost:5173 e faz proxy de /api para o
// backend Spring Boot em localhost:8080, evitando problemas de CORS
// durante o desenvolvimento.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:8080',
        changeOrigin: true
      }
    }
  }
})
