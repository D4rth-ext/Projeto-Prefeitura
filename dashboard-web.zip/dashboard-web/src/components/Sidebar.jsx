import { NavLink, Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { PERFIS } from '../context/AuthContext'

const ITENS_BASE = [
  { to: '/', label: 'Ordens de serviço', icon: 'ti-clipboard-list', perfis: null },
  { to: '/equipamentos', label: 'Equipamentos', icon: 'ti-devices', perfis: [PERFIS.ADMIN, PERFIS.ATENDENTE, PERFIS.TECNICO] },
  { to: '/setores', label: 'Setores', icon: 'ti-building', perfis: [PERFIS.ADMIN, PERFIS.ATENDENTE] },
  { to: '/tecnicos', label: 'Técnicos e usuários', icon: 'ti-users', perfis: [PERFIS.ADMIN] },
  { to: '/agenda', label: 'Agenda de técnicos', icon: 'ti-calendar', perfis: [PERFIS.ADMIN, PERFIS.TECNICO, PERFIS.ATENDENTE] },
  { to: '/backups', label: 'Descarte de backups', icon: 'ti-database', perfis: [PERFIS.ADMIN, PERFIS.ATENDENTE] },
  { to: '/relatorios', label: 'Relatórios', icon: 'ti-chart-bar', perfis: [PERFIS.ADMIN] }
]

export default function Sidebar() {
  const { usuario, logout } = useAuth()

  const itensVisiveis = ITENS_BASE.filter(
    (item) => !item.perfis || item.perfis.includes(usuario?.perfil)
  )

  return (
    <aside style={{ width: 200, flexShrink: 0, background: 'var(--green-dark)', color: '#fff' }}>
      <div style={{ padding: '18px 16px', display: 'flex', alignItems: 'center', gap: 10, borderBottom: '1px solid rgba(255,255,255,0.15)', fontWeight: 600, fontSize: 15 }}>
        <i className="ti ti-tool" style={{ fontSize: 22 }} />
        Manutenção TI
      </div>

      <Link
        to="/perfil"
        style={{
          padding: '12px 16px', fontSize: 12, opacity: 0.9, display: 'flex', alignItems: 'center',
          gap: 8, borderBottom: '1px solid rgba(255,255,255,0.1)', color: '#fff', textDecoration: 'none'
        }}
      >
        {usuario?.fotoUrl ? (
          <img src={usuario.fotoUrl} alt="" style={{ width: 22, height: 22, borderRadius: '50%', objectFit: 'cover', flexShrink: 0 }} />
        ) : (
          <i className="ti ti-user-circle" style={{ fontSize: 16 }} />
        )}
        <span>{usuario?.nome} · {usuario?.perfil?.toLowerCase()}</span>
      </Link>

      <nav style={{ padding: '8px 0', display: 'flex', flexDirection: 'column' }}>
        {itensVisiveis.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === '/'}
            style={({ isActive }) => ({
              color: '#fff',
              textDecoration: 'none',
              padding: '10px 16px 10px 13px',
              display: 'flex',
              alignItems: 'center',
              gap: 10,
              fontSize: 13,
              opacity: isActive ? 1 : 0.85,
              fontWeight: isActive ? 500 : 400,
              background: isActive ? 'rgba(255,255,255,0.12)' : 'transparent',
              borderLeft: isActive ? '3px solid #fff' : '3px solid transparent'
            })}
          >
            <i className={`ti ${item.icon}`} style={{ fontSize: 16, width: 18 }} />
            {item.label}
          </NavLink>
        ))}
      </nav>

      <button
        onClick={logout}
        style={{
          margin: '12px 16px', background: 'transparent', border: '1px solid rgba(255,255,255,0.3)',
          color: '#fff', borderRadius: 6, padding: '8px 12px', fontSize: 12, cursor: 'pointer',
          display: 'flex', alignItems: 'center', gap: 6
        }}
      >
        <i className="ti ti-logout" />
        Sair
      </button>
    </aside>
  )
}
